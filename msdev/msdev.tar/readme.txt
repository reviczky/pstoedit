This directory contains the project files needed to build pstoedit using MS VC++ 7.0. 
This directory is expected to reside in parallel to the src directory, i.e. as direct
subdirectory of the pstoedit root directory. This is needed because the projects address
the sources using relative pathes.

The top project is msvc_top.vcproj. THere are three subprojects
1. ptoedll - this builds the core pstoedit.dll and pstoedit.lib
2. stddrivers - this builds the standard drivers
3. pstoeditmain - this builds the small main program pstoedit.exe

When building the msvc_top project, all the subprojects will be built automatically so 
there is no need to build them manually

Wolfgang Glunz - wglunz@pstoedit.net